package Exercises.P04_TrafficLights;

public enum TrafficLightState {
    RED, YELLOW, GREEN;
}
