package P05_BorderControl;
/* @created by Ch.B. on 22-Mar-21 - 22:45 */

public interface Identifiable {
    String getId();
}
