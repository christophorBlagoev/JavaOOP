package P02_CarShopExtended;
/* @created by Ch.B. on 22-Mar-21 - 19:45 */

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
