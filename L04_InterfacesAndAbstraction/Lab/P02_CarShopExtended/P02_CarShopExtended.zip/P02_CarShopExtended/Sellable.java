package P02_CarShopExtended;
/* @created by Ch.B. on 22-Mar-21 - 19:36 */

public interface Sellable {
    Double getPrice();
}
