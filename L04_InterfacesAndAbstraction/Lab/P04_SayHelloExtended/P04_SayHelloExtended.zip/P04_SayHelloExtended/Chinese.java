package P04_SayHelloExtended;
/* @created by Ch.B. on 22-Mar-21 - 21:34 */

public class Chinese extends BasePerson{

    public Chinese(String name) {
        super(name);
    }

    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }
}
