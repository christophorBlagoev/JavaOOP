package P04_SayHelloExtended;
/* @created by Ch.B. on 22-Mar-21 - 21:33 */

public interface Person {
    String getName();
    String sayHello();
}
