package P04_SayHelloExtended;
/* @created by Ch.B. on 22-Mar-21 - 21:34 */

public class European extends BasePerson{

    public European(String name) {
        super(name);
    }
}
