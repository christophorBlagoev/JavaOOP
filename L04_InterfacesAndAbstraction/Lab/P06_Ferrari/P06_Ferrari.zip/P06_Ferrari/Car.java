package P06_Ferrari;
/* @created by Ch.B. on 22-Mar-21 - 22:55 */

public interface Car {
    String brakes();

    String gas();
}
