package P04_FoodShortage;
/* @created by Ch.B. on 23-Mar-21 - 21:11 */

public interface Buyer {
    void buyFood();

    int getFood();
}
