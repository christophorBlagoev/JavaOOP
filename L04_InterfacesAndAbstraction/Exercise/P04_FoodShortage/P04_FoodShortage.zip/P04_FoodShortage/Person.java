package P04_FoodShortage;
/* @created by Ch.B. on 23-Mar-21 - 21:13 */

public interface Person {
    String getName();

    int getAge();
}
