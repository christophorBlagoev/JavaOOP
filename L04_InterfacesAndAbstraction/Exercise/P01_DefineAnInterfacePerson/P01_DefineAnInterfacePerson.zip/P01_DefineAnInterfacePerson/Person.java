package P01_DefineAnInterfacePerson;
/* @created by Ch.B. on 23-Mar-21 - 18:49 */

public interface Person {
    String getName();

    int getAge();
}
