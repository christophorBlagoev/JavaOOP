package P03_BirthdayCelebrations;
/* @created by Ch.B. on 23-Mar-21 - 19:39 */

public interface Creature {
    String getName();
}
