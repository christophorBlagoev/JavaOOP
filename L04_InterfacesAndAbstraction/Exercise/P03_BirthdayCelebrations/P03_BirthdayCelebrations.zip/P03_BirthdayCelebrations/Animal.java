package P03_BirthdayCelebrations;
/* @created by Ch.B. on 23-Mar-21 - 19:45 */

public interface Animal extends Creature {
}
