package P03_BirthdayCelebrations;
/* @created by Ch.B. on 23-Mar-21 - 18:58 */

public interface Person extends Creature{

    int getAge();
}
