package P03_BirthdayCelebrations;
/* @created by Ch.B. on 23-Mar-21 - 19:09 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    }
}
