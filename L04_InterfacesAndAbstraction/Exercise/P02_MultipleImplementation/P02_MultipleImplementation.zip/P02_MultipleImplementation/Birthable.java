package P02_MultipleImplementation;
/* @created by Ch.B. on 23-Mar-21 - 18:59 */

public interface Birthable {
    String getBirthDate();
}
