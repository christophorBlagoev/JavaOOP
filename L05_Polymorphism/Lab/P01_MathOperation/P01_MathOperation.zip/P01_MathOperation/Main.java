package P01_MathOperation;
/* @created by Ch.B. on 24-Mar-21 - 12:00 */

public class Main {
    public static void main(String[] args) {

        System.out.println(MathOperation.add(2, 2));
        System.out.println(MathOperation.add(3, 3, 3));
        System.out.println(MathOperation.add(4, 4, 4, 4));
    }
}
