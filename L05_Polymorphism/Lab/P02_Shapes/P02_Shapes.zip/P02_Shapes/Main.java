package P02_Shapes;
/* @created by Ch.B. on 24-Mar-21 - 12:30 */

public class Main {
    public static void main(String[] args) {

    }
}
