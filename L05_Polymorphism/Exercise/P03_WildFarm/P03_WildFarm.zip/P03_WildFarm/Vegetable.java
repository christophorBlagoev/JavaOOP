package P03_WildFarm;
/* @created by Ch.B. on 28-Mar-21 - 18:26 */

public class Vegetable extends Food{

    public Vegetable(int quantity) {
        super(quantity);
    }
}
