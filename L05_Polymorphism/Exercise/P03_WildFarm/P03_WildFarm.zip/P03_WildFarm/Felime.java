package P03_WildFarm;
/* @created by Ch.B. on 28-Mar-21 - 18:49 */

public abstract class Felime extends Mammal {

    protected Felime(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
