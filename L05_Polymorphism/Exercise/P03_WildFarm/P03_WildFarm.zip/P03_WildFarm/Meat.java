package P03_WildFarm;
/* @created by Ch.B. on 28-Mar-21 - 18:27 */

public class Meat extends Food{

    public Meat(int quantity) {
        super(quantity);
    }
}
