package P03_WildFarm;
/* @created by Ch.B. on 28-Mar-21 - 18:23 */

public abstract class Food {
    private int quantity;

    public Food(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }
}
