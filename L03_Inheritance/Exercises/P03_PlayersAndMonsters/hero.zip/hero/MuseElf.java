package hero;
/* @created by Ch.B. on 19-Mar-21 - 19:23 */

public class MuseElf extends Elf {

    public MuseElf(String username, int level) {
        super(username, level);
    }
}
