package hero;
/* @created by Ch.B. on 19-Mar-21 - 19:24 */

public class Wizard extends Hero {

    public Wizard(String username, int level) {
        super(username, level);
    }
}
