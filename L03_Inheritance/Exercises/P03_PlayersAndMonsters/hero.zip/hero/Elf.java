package hero;
/* @created by Ch.B. on 19-Mar-21 - 19:13 */

public class Elf extends Hero {

    public Elf(String username, int level){
        super(username, level);
    }
}
