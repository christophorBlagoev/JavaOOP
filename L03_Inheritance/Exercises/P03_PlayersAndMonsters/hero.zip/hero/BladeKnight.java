package hero;
/* @created by Ch.B. on 19-Mar-21 - 19:28 */

public class BladeKnight extends DarkKnight {

    public BladeKnight(String username, int level) {
        super(username, level);
    }
}
