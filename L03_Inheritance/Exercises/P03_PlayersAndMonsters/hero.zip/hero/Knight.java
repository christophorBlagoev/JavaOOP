package hero;
/* @created by Ch.B. on 19-Mar-21 - 19:27 */

public class Knight extends Hero {

    public Knight(String username, int level) {
        super(username, level);
    }
}
