package p04_NeedForSpeed;
/* @created by Ch.B. on 19-Mar-21 - 19:54 */

public class CrossMotorcycle extends Motorcycle{

    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
