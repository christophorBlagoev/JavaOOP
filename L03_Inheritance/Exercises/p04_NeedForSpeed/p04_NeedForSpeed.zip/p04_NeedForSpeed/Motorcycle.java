package p04_NeedForSpeed;
/* @created by Ch.B. on 19-Mar-21 - 19:53 */

public class Motorcycle extends Vehicle{

    public Motorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
