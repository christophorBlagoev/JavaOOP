package p04_NeedForSpeed;
/* @created by Ch.B. on 19-Mar-21 - 20:01 */

public class FamilyCar extends Car{

    public FamilyCar(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
