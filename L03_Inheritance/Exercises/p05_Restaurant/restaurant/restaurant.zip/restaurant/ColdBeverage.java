package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 22:44 */

import java.math.BigDecimal;

public class ColdBeverage extends Beverage {

    public ColdBeverage(String name, BigDecimal price, double milliliters){
        super(name, price, milliliters);
    }
}
