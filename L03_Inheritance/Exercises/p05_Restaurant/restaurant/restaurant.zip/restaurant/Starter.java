package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 22:56 */

import java.math.BigDecimal;

public class Starter extends Food{

    public Starter(String name, BigDecimal price, double grams){
        super(name, price, grams);
    }

}
