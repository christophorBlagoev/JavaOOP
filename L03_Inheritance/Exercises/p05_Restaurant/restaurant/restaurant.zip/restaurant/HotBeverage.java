package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 22:42 */

import java.math.BigDecimal;

public class HotBeverage extends Beverage {

    public HotBeverage(String name, BigDecimal price, double milliliters){
        super(name, price, milliliters);
    }
}
