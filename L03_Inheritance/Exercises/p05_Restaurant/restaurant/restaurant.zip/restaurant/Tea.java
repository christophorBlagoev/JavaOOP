package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 22:46 */

import java.math.BigDecimal;

public class Tea extends HotBeverage{

    public Tea(String name, BigDecimal price, double milliliters){
        super(name, price, milliliters);
    }
}
