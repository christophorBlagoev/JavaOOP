package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 22:54 */

import java.math.BigDecimal;

public class MainDish extends Food{

    public MainDish(String name, BigDecimal price, double grams){
        super(name, price, grams);
    }
}
