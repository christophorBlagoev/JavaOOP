package restaurant;
/* @created by Ch.B. on 19-Mar-21 - 23:00 */

import java.math.BigDecimal;

public class Soup extends Starter{

    public Soup(String name, BigDecimal price, double grams){
        super(name, price, grams);
    }
}
