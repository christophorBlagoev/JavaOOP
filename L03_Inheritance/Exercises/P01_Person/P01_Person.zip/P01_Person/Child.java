package P01_Person;
/* @created by Ch.B. on 18-Mar-21 - 23:06 */

public class Child extends Person{
    public Child(String name, int age) {
        super(name, age);
    }
}
